import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:scratch_clone/core/result.dart';
import 'package:scratch_clone/entity/data/entity.dart';
import 'package:scratch_clone/node_feature/data/connection_point_model.dart';
import 'package:scratch_clone/node_feature/data/node_model.dart';
import 'package:scratch_clone/node_feature/data/node_types.dart';
import 'package:scratch_clone/node_feature/presentation/flow_control_node_widgets/simple_condition_node_widget.dart';

class SimpleConditionNode extends NodeModel with HasOutput {
  dynamic firstOperand;
  dynamic secondOperand;
  String? comparisonOperator;

  SimpleConditionNode({
    super.position,
    this.firstOperand,
    this.secondOperand,
    this.comparisonOperator,
  }) : super(
            color: Colors.yellow,
            width: 200,
            height: 100,
            connectionPoints: [
              OutputConnectionPoint(position: Offset.zero, width: 20),
            ],
          );

  @override
  Result<bool> execute([Entity? activeEntity]) {
    double? op1;
    double? op2;

    if (firstOperand == null || secondOperand == null || comparisonOperator == null) {
      return Result.failure(errorMessage: "Missing operand or operator");
    }

    if (activeEntity != null) {
      if (activeEntity.variables.containsKey(firstOperand)) {
        op1 = activeEntity.variables[firstOperand];
      }
      if (activeEntity.variables.containsKey(secondOperand)) {
        op2 = activeEntity.variables[secondOperand];
      }
    }

    op1 ??= double.tryParse(firstOperand.toString());
    op2 ??= double.tryParse(secondOperand.toString());

    switch (comparisonOperator) {
      case "==":
        return Result.success(result: op1 == op2);
      case ">":
        return Result.success(result: op1! > op2!);
      case "<":
        return Result.success(result: op1! < op2!);
      default:
        return Result.failure(errorMessage: "Invalid operator");
    }
  }

  void setFirstOperand(String value) {
    firstOperand = value;
    notifyListeners();
  }

  void setSecondOperand(String value) {
    secondOperand = value;
    notifyListeners();
  }

  void setOperator(String value) {
    comparisonOperator = value;
    notifyListeners();
  }

  @override
  Widget buildNode() {
    return ChangeNotifierProvider.value(
      value: this,
      child: SimpleConditionNodeWidget(node: this),
    );
  }

  @override
  NodeModel copyWith({
    Offset? position,
    Color? color,
    double? width,
    double? height,
    bool? isConnected,
    NodeModel? child,
    NodeModel? parent,
    dynamic firstOperand,
    dynamic secondOperand,
    String? comparisonOperator,
    NodeModel? output,
    List<ConnectionPointModel>? connectionPoints,
  }) {
    return SimpleConditionNode(
      position: position ?? this.position,
    )
      ..firstOperand = firstOperand ?? this.firstOperand
      ..secondOperand = secondOperand ?? this.secondOperand
      ..comparisonOperator = comparisonOperator ?? this.comparisonOperator
      ..isConnected = isConnected ?? this.isConnected
      ..child = child ?? this.child?.copy()
      ..parent = parent ?? this.parent?.copy()
      ..output = output ?? this.output?.copy()
      ..connectionPoints = connectionPoints ?? List<ConnectionPointModel>.from(this.connectionPoints.map((cp) => cp.copy()));
  }

  @override
  SimpleConditionNode copy() {
    return copyWith(
      position: position,
      color: color,
      width: width,
      height: height,
      isConnected: isConnected,
      child: child?.copy(),
      parent: parent?.copy(),
      firstOperand: firstOperand,
      secondOperand: secondOperand,
      comparisonOperator: comparisonOperator,
      output: output?.copy(),
    ) as SimpleConditionNode;
  }

  

  Map<String, dynamic> toMap() {
    return <String, dynamic>{
      'firstOperand': firstOperand,
      'secondOperand': secondOperand,
      'comparisonOperator': comparisonOperator,
    };
  }

  factory SimpleConditionNode.fromMap(Map<String, dynamic> map) {
    return SimpleConditionNode(
      firstOperand: map['firstOperand'] as dynamic,
      secondOperand: map['secondOperand'] as dynamic,
      comparisonOperator: map['comparisonOperator'] != null ? map['comparisonOperator'] as String : null,
    );
  }



  
}
